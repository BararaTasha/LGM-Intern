```python
#TASK-1:Image to Pencil Sketch with Python:
#We need to read the image in RBG format and then convert it to a grayscale image.
#This will turn an image into a classic black and white photo. 
#Then the next thing to do is invert the grayscale image also called negative image, this will be our inverted grayscale image.
```


```python
pip install opencv-python
```

    Defaulting to user installation because normal site-packages is not writeable
    Requirement already satisfied: opencv-python in c:\users\dell\appdata\roaming\python\python39\site-packages (4.7.0.68)
    Requirement already satisfied: numpy>=1.17.0 in c:\programdata\anaconda3\lib\site-packages (from opencv-python) (1.21.5)
    Note: you may need to restart the kernel to use updated packages.
    


```python
import cv2
```


```python
img = cv2.imread("C:\Users\DELL\OneDrive\Pictures\shivji 2.jpg")
cv2.imshow(img)
```


      Input In [6]
        img = cv2.imread("C:\Users\DELL\OneDrive\Pictures\shivji 2.jpg")
                                                                       ^
    SyntaxError: (unicode error) 'unicodeescape' codec can't decode bytes in position 2-3: truncated \UXXXXXXXX escape
    



```python
img = cv2.imread("C:\\Users\\DELL\\OneDrive\\Pictures\\shivji 2.jpg",1)
```


```python
cv2.imshow("shivji 2", img)
cv2.waitKey(0) 
```




    -1




```python
import matplotlib.pyplot as plt
%matplotlib inline
img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
plt.imshow(img_rgb)
```




    <matplotlib.image.AxesImage at 0x20891870cd0>




    
![png](output_6_1.png)
    


# Converting image into gray_scale image


```python
img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
cv2.imshow("New Shivji", img_gray)
cv2.waitKey(0)
```




    -1




```python
plt.imshow(img_gray)
```




    <matplotlib.image.AxesImage at 0x208938ea790>




    
![png](output_9_1.png)
    


# Inverting the image


```python
img_invert =  255 - img_gray
cv2.imshow("Inverted", img_invert)
cv2.waitKey(0)
```




    -1




```python
plt.imshow(img_invert)
```




    <matplotlib.image.AxesImage at 0x20893950a60>




    
![png](output_12_1.png)
    



```python
blurred = cv2.GaussianBlur(img_invert, (21, 23), 0)
```


```python
plt.imshow(blurred)
```




    <matplotlib.image.AxesImage at 0x208939ba520>




    
![png](output_14_1.png)
    



```python
inverted_blurred = 255 - blurred
pencil_sketch = cv2.divide(img_gray, inverted_blurred, scale=256.0)
cv2.imshow("Sketch", pencil_sketch)
cv2.waitKey(0)
```




    -1




```python
plt.imshow(pencil_sketch)
```




    <matplotlib.image.AxesImage at 0x20893a14f40>




    
![png](output_16_1.png)
    

